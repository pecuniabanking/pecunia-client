/***************************************************************************
    begin       : Sat May 08 2010
    copyright   : (C) 2010 by Martin Preuss
    email       : martin@libchipcard.de

 ***************************************************************************
 *          Please see toplevel file COPYING for license details           *
 ***************************************************************************/

#ifndef AQPAYPAL_PROVIDER_H
#define AQPAYPAL_PROVIDER_H


#include <aqbanking/provider_be.h>

#include <aqpaypal/aqpaypal.h>






#endif


