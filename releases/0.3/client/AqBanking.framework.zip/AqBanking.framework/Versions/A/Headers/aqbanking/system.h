/***************************************************************************
 $RCSfile$
 -------------------
 cvs         : $Id$
 begin       : Mon Mar 01 2004
 copyright   : (C) 2004 by Martin Preuss
 email       : martin@libchipcard.de

 ***************************************************************************
 *          Please see toplevel file COPYING for license details           *
 ***************************************************************************/


#ifndef AQBANKING_SYSTEM_H
#define AQBANKING_SYSTEM_H

#define AQBANKING_SYS_IS_WINDOWS 0
#define AQBANKING_SYSTEM "osx"


#endif

